﻿=== Phetsarath Bold ===
Contributors: Phoukham MANIVANH
Tags: phetsarath, phetsarath bold, phetsarath for wordpress, phetsarath wp, ພາສາລາວ, ເພັດຊະລາດ, ຟອນລາວ, font lao, lao font, lao font bold, lao font for wp, lao font bold for wordpress
Tested up to: 4.9.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Change Lao font to Phetsarath Bold is easyly.
Since Lao's standard font is Phetsarath OT but Phetsarath OT is likely thin, so if you need Phetsarath OT to be Bold one, this plugin is your solution. That's the purpose of this plugin.

Features
* Only Active then you get Phetsarath Bold font on Wordpress.


== Installation ==
1. Upload the "phetsarath-bold" files to 'wp-content/plugins/' directory.
2. Active the 'Phetsarath Bold' plugin.
3. Enjoy!

== Frequently Asked Questions ==
N/A

== Screenshots ==
Phetsarath OT font : https://s18.postimg.org/jnkqbjyjt/Phetsarath-_OT.jpg
Phetsarath Bold font: https://s18.postimg.org/6w6k5g1qx/Phetsarath-_Bold.jpg

== Upgrade Notice ==
This is First version

== Changelog ==
=1.0=
Active and play!