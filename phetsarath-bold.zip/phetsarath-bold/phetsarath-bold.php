<?php
/* Plugin Name:  Phetsarath Bold
Plugin URI:      http://dpt-odx.gov.la/
Description:     Switch your lao font on Wordpress to Phetsarath Bold, only install and Active!.
Version:         1.0
Author:          Phoukham MANIVANH
Author URI:      http://kpitee.edu.la/
Developer:       Phoukham MANIVANH
Developer URI:   http://kpitee.edu.la/
Copyright:       © 2018 Phoukham MANIVANH.
Email : laocyberspace@gmail.com
Website : http://kpitee.edu.la
Facebook : www.facebook.com/laocyberspace.mit
License:         GNU General Public License v3.0
License URI:     http://www.gnu.org/licenses/gpl-3.0.html
 */

 // Action
add_action('wp_enqueue_scripts','phetsarathbold');
add_action('admin_enqueue_scripts','phetsarathbold');

// call style
function phetsarathbold() {
	$locate = plugins_url('fonts/style.css',__FILE__);
	wp_register_style( 'phetsarath-bold',$locate);
	wp_enqueue_style('phetsarath-bold');
	
}


?>