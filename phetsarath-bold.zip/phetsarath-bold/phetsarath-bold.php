<?php
/*
  Plugin Name: Phetsarath Bold
  Plugin URI: http://kpitee.edu.la
  Description: Switch your lao font on Wordpress to Phetsarath Bold, only install and Active!.
  Version: 1.0
  Author: Phoukham MANIVANH
  Author URI: http://kpitee.edu.la
  License: GPL
*/

/* copyright 2018 Phoukham MANIVANH
Email : laocyberspace@gmail.com
Website : http://kpitee.edu.la
Facebook : www.facebook.com/laocyberspace.mit
 */

 // Action
add_action('wp_enqueue_scripts','phetsarathbold');
add_action('admin_enqueue_scripts','phetsarathbold');

// call style
function phetsarathbold() {
	$locate = plugins_url('fonts/style.css',__FILE__);
	wp_register_style( 'phetsarath-bold',$locate);
	wp_enqueue_style('phetsarath-bold');
	
}


?>